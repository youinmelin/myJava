package lin;

import lin.domain.Account;
import lin.domain.FilenameAndMsg;
import lin.domain.User;
import lin.service.IAccountService;
import lin.service.IFileMsgService;
import lin.service.IUserService;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

public class TestSpring {


    ApplicationContext ac;
    IAccountService accountService;
    IFileMsgService fileMsgService;
    IUserService userService;

    @Before
    public void init() {
        ac = new ClassPathXmlApplicationContext("classpath:applicationContext.xml");
        accountService = ac.getBean("accountService", IAccountService.class);
        fileMsgService = ac.getBean("fileMsgService", IFileMsgService.class);
        userService = ac.getBean("userService", IUserService.class);
    }

    @Test
    public void testRun1() {
        List<Account> accounts = accountService.findAllAccount();
        for (Account account :
                accounts) {
            System.out.println(account);
        }
    }

    @Test
    public void testSaveFileMsg() {
        FilenameAndMsg fileMsg = new FilenameAndMsg(null,1, "test", "index.jsp", 500,null,null);
        fileMsgService.saveFileMsg(fileMsg);
    }
    @Test
    public void testFindAllFileMsg() {
        List<FilenameAndMsg> allFileMsg = fileMsgService.findAllFileMsg();
        for (FilenameAndMsg fm :
                allFileMsg) {
            System.out.println(fm);
        }
    }

    // one to many
    @Test
    public void testFindUserWithMsg() {
        List<User> list = userService.findMsgWithUser();
        for (User user :
                list) {
            System.out.println(user);
            System.out.println(user.getMessages());
        }
    }

    // one to one
    @Test
    public void testFindMsgWithUser() {
        List<FilenameAndMsg> msgList = fileMsgService.findMsgWithUser();
        for (FilenameAndMsg fm :
                msgList) {
            System.out.println(fm);
            System.out.println(fm.getUser());
        }
    }
}
