package lin.domain;

import java.io.Serializable;
import java.util.Date;

public class FilenameAndMsg implements Serializable {

    private Integer msgId;
    private Integer uId;
    private String message;
    private String filenameFull;
    private Integer filesize;
    private String datetime;
    private User user;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    @Override
    public String toString() {
        return "FilenameAndMsg{" +
                "msgId=" + msgId +
                ", uId=" + uId +
                ", message='" + message + '\'' +
                ", filenameFull='" + filenameFull + '\'' +
                ", filesize=" + filesize +
                ", datetime='" + datetime + '\'' +
                '}';
    }

    public FilenameAndMsg(Integer msgId, Integer uId, String message, String filenameFull, Integer filesize, String datetime) {
        this.msgId = msgId;
        this.uId = uId;
        this.message = message;
        this.filenameFull = filenameFull;
        this.filesize = filesize;
        this.datetime = datetime;
    }

    public FilenameAndMsg(Integer msgId, Integer uId, String message, String filenameFull, Integer filesize, String datetime, User user) {
        this.msgId = msgId;
        this.uId = uId;
        this.message = message;
        this.filenameFull = filenameFull;
        this.filesize = filesize;
        this.datetime = datetime;
        this.user = user;
    }

    public Integer getMsgId() {
        return msgId;
    }


    public void setMsgId(Integer msgId) {
        this.msgId = msgId;
    }

    public Integer getuId() {
        return uId;
    }

    public void setuId(Integer uId) {
        this.uId = uId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getFilenameFull() {
        return filenameFull;
    }

    public void setFilenameFull(String filenameFull) {
        this.filenameFull = filenameFull;
    }

    public Integer getFilesize() {
        return filesize;
    }

    public void setFilesize(Integer filesize) {
        this.filesize = filesize;
    }

    public String getDatetime() {
        return datetime;
    }

    public void setDatetime(String datetime) {
        this.datetime = datetime;
    }
}
