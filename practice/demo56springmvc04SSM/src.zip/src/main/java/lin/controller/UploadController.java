package lin.controller;

import lin.dao.IFileMsgDao;
import lin.domain.FilenameAndMsg;
import lin.service.IAccountService;
import lin.service.IFileMsgService;
import org.apache.commons.io.FileUtils;
import org.aspectj.util.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/upload")
public class UploadController {

    @Autowired
    private IFileMsgService fileMsgService;

    private final String UPLOADPATH = "/upload";


    /**
     * upload file , create FilenameAndMsg object, save infomation into database
     * @param request
     * @param response
     * @param upload
     * @param uId
     * @param msg
     * @return
     */
    @RequestMapping("/uploadFileMsg")
    public String uploadFileAndMsg(HttpServletRequest request, HttpServletResponse response, MultipartFile upload, Integer uId, String msg) {

//        Cookie cookie = new Cookie("uname", uId.toString());
//        cookie.setMaxAge(3600*30);
//        cookie.setPath("/");
//        response.addCookie(cookie);
//        System.out.println("set cookie age=30 days path = /");

        String path = request.getSession().getServletContext().getRealPath(UPLOADPATH);
        String filename = null;
        System.out.println("path:" + path);
        File file = new File(path);
        makedir(file);
        try {
            filename = upload.getOriginalFilename();
            upload.transferTo(new File(path, filename));
        } catch (IOException e) {
//            e.printStackTrace();
            System.out.println("no filename");
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
        System.out.println("contextpath: "+request.getContextPath() + UPLOADPATH );
        System.out.println("file size:" + upload.getSize()/1024 + "k");
        System.out.println(path + "\\" + filename);

        // turn filesize from byte to M
        int filesize = (int) (upload.getSize()/1024/1024);
        // if msg is empty, then filename is msg
        msg = msg.equals("")?filename:msg;
        System.out.println("userId: " + uId + "  msg: " + msg);
        // create FilenameAndMsg object
        FilenameAndMsg filemsg = new FilenameAndMsg(null,uId, msg, filename, filesize,null, null);
        System.out.println("USL: " + filemsg);
        // save to database
        fileMsgService.saveFileMsg(filemsg);
         try {
             response.sendRedirect(request.getContextPath() + "/upload/findAllFileMsg");
         } catch (IOException e) {
             e.printStackTrace();
         }
         return "success";
    }


    @RequestMapping("/findAllFileMsg")
    public ModelAndView findAllFileMsg(ModelAndView mv) {
        System.out.println("USL: find all file msg");
        List<FilenameAndMsg> allFileMsg = fileMsgService.findAllFileMsg();
        mv.addObject("fileMsgList", allFileMsg);
        mv.setViewName("../../index");
//        mv.setViewName("show_file_msg");
//        for (FilenameAndMsg fm :
//                allFileMsg) {
//            System.out.println(fm);
//        }
        return mv;
    }


    /**
     * file downloader not use
     */
    @RequestMapping("/downloadFile")
    public void downloadFile(String filename, HttpServletResponse response, HttpServletRequest request) throws Exception {
        System.out.println("USL: download file + filename");
        // config response header: download
        response.setHeader("Content-Disposition", "attachment;filename" + filename);
        // get outputStream
        ServletOutputStream os = response.getOutputStream();
        // get file's absolute path
        String path = request.getSession().getServletContext().getRealPath(UPLOADPATH);
        // create files list
        System.out.println(filename);
        File file = new File(path, filename);
        // turn the file to byte[]
        byte[] readFileToByteArray = FileUtils.readFileToByteArray(file);
        os.write(readFileToByteArray);
        os.flush();
        os.close();

    }

    /**
     * use well
     * @param filename
     * @param req
     * @param resp
     * @return
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value ="/DownloadFile")
    public ResponseEntity<byte[]> DownloadFile(String filename, HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException {
        //  接受的是UTF-8
        req.setCharacterEncoding("utf-8");
        //获取项目根目录
        String path = req.getSession().getServletContext().getRealPath(UPLOADPATH + "\\" + filename);
//        System.out.println("path: " + path);
        //获取文件名
        File file = null;
        HttpHeaders headers = null;
        try {
//            System.out.println("filename:" + filename);//myfiles
            file = new File(path);
            //请求头
            headers = new HttpHeaders();
            String fileName1 = new String(filename.getBytes("UTF-8"), "iso-8859-1");//解决文件名乱码
            //通知浏览器以attachment（下载方式）打开
            headers.setContentDispositionFormData("attachment", fileName1);
            //application/octet-stream二进制流数据（最常见的文件下载）。
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return new ResponseEntity<byte[]>(FileUtils.readFileToByteArray(file), headers, HttpStatus.OK);
    }

    private void makedir(File file) {
        if (!file.exists()) {
            System.out.println("mkdirs");
            file.mkdirs();
        }
    }
}
