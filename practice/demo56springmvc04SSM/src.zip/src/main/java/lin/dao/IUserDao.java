package lin.dao;

import lin.domain.FilenameAndMsg;
import lin.domain.User;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.mapping.FetchType;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IUserDao {

    @Select("select * from user")
    List<User> findAllUser();

    @Select("select username from user where uid = #{uid}")
    String findUsernameById(Integer uid);

    @Select("select * from user where uid = #{uid}")
    @ResultMap("userMap")
    User findUserById(Integer uid);


    @Select("select * from user")
    @Results(id = "userMap", value = {
            @Result (id = true, property = "uid", column = "uid"),
            @Result(property = "uid", column = "uid"),
            @Result(property = "username", column = "username"),
            @Result(property = "departmentId", column = "departmentId"),
            @Result(property = "groupId", column = "groupId"),
            @Result(property = "authority", column = "authority"),
            @Result(property = "messages", column = "uid",
                many = @Many(select = "lin.dao.IFileMsgDao.findMsgByUid", fetchType = FetchType.LAZY))
//                many = @Many(select = "lin.dao.IFileMsgDao.findMsgByUid", fetchType = FetchType.EAGER))

})
    List<User> findMsgWithUser();

}
