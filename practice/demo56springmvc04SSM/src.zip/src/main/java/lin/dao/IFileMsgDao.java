package lin.dao;

import lin.domain.FilenameAndMsg;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.mapping.FetchType;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IFileMsgDao {

    @Select("insert into file_msg (msgid,uid,message,filename,filesize,datetime) values(null,#{uId},#{message},#{filenameFull},#{filesize},#{datetime})")
    void saveFileMsg(FilenameAndMsg filenameAndMsg);

//    @Select("select msgId,username,message,filename,datetime from file_and_msg" )
    @Select("select * from file_msg" )
    List<FilenameAndMsg> findAllFileMsg();

    @Select("select * from file_msg where uid = #{uid}")
//    @ResultMap("findMsgByUidMapper")
    List<FilenameAndMsg> findMsgByUid(Integer uid);

    @Select("select * from file_msg")
    @Results(id = "findMsgByUidMapper", value = {
            @Result (id = true, column = "msgid", property = "msgId" ),
            @Result (column = "uid", property = "uId"),
            @Result (column = "message", property = "message"),
            @Result (column = "filename", property = "filenameFull"),
            @Result (column = "filesize", property = "filesize"),
            @Result (column = "datetime", property = "datetime"),
            @Result (column = "uid", property = "user",
                    one = @One(select = "lin.dao.IUserDao.findUserById", fetchType = FetchType.EAGER))
    })
    List<FilenameAndMsg> findMsgWithUser();
}
