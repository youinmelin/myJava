package lin.service;

import lin.domain.FilenameAndMsg;
import org.springframework.stereotype.Service;

import java.util.List;

public interface IFileMsgService {

    public void saveFileMsg(FilenameAndMsg fileMsg);

    List<FilenameAndMsg> findAllFileMsg();

    List<FilenameAndMsg> findMsgWithUser();
}
