package lin.service.impl;

import lin.dao.IFileMsgDao;
import lin.domain.FilenameAndMsg;
import lin.service.IFileMsgService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("fileMsgService")
public class FileMsgServiceImpl implements IFileMsgService {

    @Autowired
    private IFileMsgDao fileMsgDao;

    @Override
    public void saveFileMsg(FilenameAndMsg fileMsg) {
        System.out.println("BLL: " + fileMsg);
        fileMsgDao.saveFileMsg(fileMsg);
    }

    @Override
    public List<FilenameAndMsg> findAllFileMsg() {

        System.out.println("BLL: find all file msg");
        return fileMsgDao.findAllFileMsg();
    }

    @Override
    public List<FilenameAndMsg> findMsgWithUser() {
        List<FilenameAndMsg> msgList = fileMsgDao.findMsgWithUser();
        return msgList;
    }
}
