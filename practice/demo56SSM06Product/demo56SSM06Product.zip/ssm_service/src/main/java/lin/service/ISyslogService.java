package lin.service;

import lin.domain.Syslog;

public interface ISyslogService {

    void saveSyslog(Syslog syslog);
}
